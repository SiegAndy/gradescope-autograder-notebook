autograder_version = 3.1  # DO NOT MODIFY. If notebook version does not match with autograder version, all tests will fail!!

import os
import string
import re

from collections import Counter
import Stemmer
import heapq

import urllib.request
import zipfile
from pathlib import Path

data_path = "./data/"


def download_file(file_path: str) -> list[list[str]]:
    """
    Download necessary from remote. Offload required contents into variables

    Args:
        file_path: the name of file we want to download

    Returns: an array of array of string loaded from the text.
    """
    webloc = "https://people.cs.umass.edu/~rahimi/446-S25-assignments/P2/"

    data_info = Path(data_path)
    if not data_info.exists() or not data_info.is_dir():
        print(
            f'Google folder "{data_path}" is not present or not a folder. Nothing will work from here.'
        )
        return []

    local_storage_path = Path(os.path.join(data_path, file_path))
    if local_storage_path.is_file():
        print(f'File "{file_path}" already exists, not downloading.')
    else:
        print(f'Cannot find "{file_path}" so downloading it')
        urllib.request.urlretrieve(webloc + file_path, local_storage_path)
        print("Done")

    with zipfile.ZipFile(local_storage_path, "r") as zip_ref:
        print(f'Unzipping "{data_path}"')
        zip_ref.extractall(data_path)

    file_names = [
        "P2-data-public.txt",
        "P2-data-protected.txt",
        "P2-data-PandP.txt",
        "P2-stopwords.txt",
    ]
    results = []
    for file_name in file_names:
        with open(
            os.path.join(data_path, "data", file_name), "r", encoding="utf-8-sig"
        ) as f:
            results.append([line.strip("\n") for line in f.readlines() if line])

    return results


def tokenize_space(input_str: str) -> list[str]:
    """
    Tokenize the input string into whitespace-separated tokens.

    Args:
        input_str: the input string that needs to be tokenized.

    Returns: an array of whitespace-separated tokens.
    """

    #########
    ##
    ## Implement the function here
    ##
    #########

    return [token for token in input_str.split() if token]
    return []  # You will return something before this statement


def tokenize_4grams(input_str: str) -> list[str]:
    """
    Tokenize the input string into 4-gram tokens with a sliding window of size 2.

    Args:
        input_str: the input string that should be tokenized.

    Returns: an array of 4-grams tokens.
    """

    #########
    ##
    ## Implement the function here
    ##
    #########
    input_str = re.sub(r"\s+", " ", input_str)
    if len(input_str) < 4:
        return [input_str] if input_str else []

    return [input_str[i : i + 4] for i in range(0, len(input_str) - 2, 2)]
    return []  # You will return something before this statement


def tokenize_fancy(input_str: str) -> list[str]:
    """
    Tokenize the input string into tokens using the fancy rules defined above.

    Args:
        input_str: the input string that we want to tokenize.

    Returns: an array of tokens in format,
        [
            token_1,
            token_2,
            ...
        ], e.g.,
        [
            'c',
            'a',
            '2.',
            'a2'
        ].
    """
    return [
        fancy_token
        for token in tokenize_space(input_str)
        for fancy_token in tokenize_fancy_helper(token)
    ]


def tokenize_fancy_helper(input_token: str) -> list[str]:
    """
    Tokenize ONE token into tokens using the fancy rules defined above.

    Args:
        input_token: the token that we want to tokenize.

    Returns: an array of tokens in format,
        [
            token_1,
            token_2,
            ...
        ], e.g.,
        [
            'c',
            'a',
            '2.',
            'a2'
        ].
    """

    #########
    ##
    ## Implement the function here
    ##
    #########

    recorder = []

    # Rule 1: Recognize URLs and ignore further processing on them
    url_rule = r"^((?i:http)(?i:s)?:\/\/)"  # match leading http/https
    url_strip_rule = string.punctuation.replace("/", "")
    # url_rule = r"^((?i:http)(?i:s)?:\/\/[^\s]+)([^\w]*)$"  # match leading http/https
    # url_rule = r"^[\'\"]*((?i:http)(?i:s)?:\/\/[^\s]+)([^\w]*)$", # match leading http/https
    url_match = re.match(
        url_rule,
        input_token,
    )

    if url_match:
        result_token = input_token.strip(url_strip_rule)
        recorder.append(result_token)  # Add URL without trailing punctuation
        return recorder
    # Rule 2: Convert the token to lowercase
    input_token = input_token.lower()

    # Rule 3: Treat numbers (including signs, commas, decimals) as a single token
    number_rule = r"^[\d+,\-.]*\d[\d+,\-.]*$"
    if re.match(
        number_rule, input_token
    ):  # match any [digits+-.,] and one digit and any [digits+-.,]
        # if re.match(r'^[+-]?(\d[\d,]*\.?\d*)$', token): # match [+-]digits.digits
        recorder.append(input_token)
        return recorder

    # Rule 4: Squeeze out apostrophes
    input_token = re.sub(r"'", "", input_token)

    # Rule 5: Handle all remaining punctuation as word separators
    punctuation = string.punctuation.replace(".", "").replace("-", "")
    recorder = [
        curr for curr in re.split(f"[{re.escape(punctuation)}]+", input_token) if curr
    ]

    skipped_tokens = []
    # Handling generated tokens which might applicable to rule 2 and 4 again
    for i, token in enumerate(recorder[:]):
        # (doing it again as split might create another eligiable number token)
        # Rule 3: Treat numbers (including signs, commas, decimals) as a single token
        if re.match(number_rule, token):
            skipped_tokens.append(token)

    # Rule 6: Process hyphens
    need_to_replace = []
    for i, token in enumerate(recorder[:]):
        if "-" not in token or token in skipped_tokens:
            continue
        new_tokens = [curr for curr in token.split("-") if curr] + [
            token.replace("-", "")
        ]
        need_to_replace.append((i, new_tokens))

    for org_token_idx, new_tokens in sorted(
        need_to_replace, key=lambda x: x[0], reverse=True
    ):
        if org_token_idx == len(recorder) - 1:
            recorder = recorder[:org_token_idx] + new_tokens
        else:
            recorder = (
                recorder[:org_token_idx] + new_tokens + recorder[org_token_idx + 1 :]
            )

    # Handling generated tokens which might applicable to rule 2 and 4 again
    for i, token in enumerate(recorder[:]):
        # (doing it again as split might create another eligiable number token)
        # Rule 3: Treat numbers (including signs, commas, decimals) as a single token
        if token in skipped_tokens or re.match(number_rule, token):
            continue

        # Rule 7: Treat abbreviations as a single token, remove periods
        recorder[i] = recorder[i].replace(
            ".", ""
        )  # empty token get removed in the return stmt

    return [curr for curr in recorder if curr]
    return []  # You will return something before this statement


def stopping(input_tokens: list[str], stopwords: list[str]) -> list[str]:
    """
    Applying stopping to the list of tokens.

    Args:
        input_tokens: the list of tokens
        stopwords: the list of stopwords that need to be removed from list of tokens

    Returns: a list of tokens in format
        [
            token_1,
            token_2,
            ...
        ], or for example,
        [
            "2.",
            "a2",
            "c"
        ].
    """

    #########
    ##
    ## Implement the function here
    ##
    #########

    return [curr for curr in input_tokens if curr and curr not in stopwords]
    return []  # You will return something before this statement


def stemming_s(input_tokens: list[str]) -> list[str]:
    """
    Applying suffix-s stemming to the list of tokens.

    Args:
        input_tokens: the list of tokens that we want to perform stemming.

    Returns: a list of tokens in format
        [
            token_1,
            token_2,
            ...
        ].
    """

    #########
    ##
    ## Implement the function here
    ##
    #########

    return [re.sub(r"s$", "", token) for token in input_tokens if token]

    return []  # You will return something before this statement


def stemming_porter(input_tokens: list[str]) -> list[str]:
    """
    Applying porter stemming to the list of tokens.

    Args:
        input_tokens: the list of tokens that we want to perform stemming.

    Returns: a list of tokens in format
        [
            token_1,
            token_2,
            ...
        ].
    """
    porter_stemmer = Stemmer.Stemmer("porter")
    return porter_stemmer.stemWords(input_tokens)


def preprocessing(
    input_list_str: list[str],
    tokenizer_type: str,
    stopwords: list[str] = None,
    stemming_type: str = None,
) -> list[list[str]]:
    """
    Tokenize the input strings and apply stopping and stemming if specified

    Args:
        input_list_str: the list of lines (string) that we read from the input file.
        tokenizer_type: (case-insensitive) the tokenizer method that we want to apply on the input string.
              Options are ["space", "4grams", "fancy"].
              Unrecognized value(s) are considered as "space".
        stopwords: the list of stopwords that need to be removed from list of token (omit to skip stopping)
        stemming_type: (case-insensitive) the stemming method that we want to apply on the token list.
              Options are [None, "suffix_s", "porter"].
              Default and unrecognized value(s) are considered as None.

    Returns: an array of processed tokens (tokenized then stopped then stemmed as indicated) in required format, i.e.,
        [
            ['whitespac', 'separ', 'whitespacesepar', 'token', 'p0']),
            ['2.', 'a2', 'c', 'also'],
            ...
        ].
    """
    tokenizer_method = tokenize_space
    if tokenizer_type.lower() == "4grams":
        tokenizer_method = tokenize_4grams
    elif tokenizer_type.lower() == "fancy":
        tokenizer_method = tokenize_fancy

    stopping_method = lambda x: x
    if stopwords is not None:
        stopping_method = lambda x: stopping(x, stopwords=stopwords)

    stemming_method = lambda x: x  # a function that returns its argument
    if stemming_type is None:
        stemming_method = lambda x: x
    elif stemming_type.lower() == "porter":
        stemming_method = stemming_porter
    elif stemming_type.lower() == "suffix_s":
        stemming_method = stemming_s

    recorder = []
    for input_str in input_list_str:  # every line
        recorder.append(
            stemming_method(stopping_method(tokenizer_method(input_str))),
        )

    #########
    ##
    ## Implement the function here
    ##
    #########

    return recorder


def freq_stats(
    processed_tokens: list[list[str]],
) -> list[tuple[str, int]]:
    """
    Analyze the processed tokens.

    Args:
        processed_tokens: the list of processed tokens in the expected format.

    Returns:
        ..... in required format, i.e.,
        [
            ("Test", 10),
            ("Token", 10),
            ("Apple", 9),
            ...
        ].
    """
    #########
    ##
    ## Implement the function here
    ##
    #########

    token_counter = Counter()
    # token_counter: Counter = sum([Counter(sub_tokens) for _, sub_tokens in processed_tokens], Counter())
    for tokens in processed_tokens:
        token_counter.update(tokens)

    heap = [(-freq, key) for key, freq in token_counter.items()]
    heapq.heapify(heap)

    return [
        (key, -freq) for freq, key in (heapq.heappop(heap) for _ in range(len(heap)))
    ]
    # return (
    #     sum(token_counter.values()),
    #     len(token_counter),
    #     [(key, -freq) for freq, key in [heapq.heappop(heap) for _ in range(top_k)]],
    # )
    return []  # You will return something before this statement
