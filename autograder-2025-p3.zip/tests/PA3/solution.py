autograder_version = 3.4  # DO NOT MODIFY. If notebook does not match with autograder version, all tests will fail!!

import numpy as np
from tabulate import tabulate
import os

from collections import Counter, defaultdict

import urllib.request
import zipfile
from pathlib import Path

data_path = "./data/"  ## DO NOT MODIFY THIS LINE. CHANGING THIS LINE WOULD RESULT IN FAIL OF AUTOGRADER TESTS


def defaultdict_to_dict(d):
    if isinstance(d, defaultdict):
        # Recursively convert each value
        d = {k: defaultdict_to_dict(v) for k, v in d.items()}
    return d


def download_file(
    file_path: str,
) -> tuple[dict[str, str], dict[str, dict[str, int]], dict[str, str], dict[str, str]]:
    """
    Download necessary from remote. Offload required contents into variables

    Args:
        file_path: the name of file we want to download

    Returns: a tuple of contents loaded from the files.
    """
    webloc = "https://people.cs.umass.edu/~rahimi/446-S25-assignments/P3/"

    data_info = Path(data_path)
    if not data_info.exists() or not data_info.is_dir():
        print(
            f'Google folder "{data_path}" is not present or not a folder. Nothing will work from here.'
        )
        return []

    local_storage_path = Path(os.path.join(data_path, file_path))
    if local_storage_path.is_file():
        print(f'File "{file_path}" already exists, not downloading.')
    else:
        print(f'Cannot find "{file_path}" at "{data_path}" so downloading it')
        urllib.request.urlretrieve(webloc + file_path, local_storage_path)
        print("Done")

    with zipfile.ZipFile(local_storage_path, "r") as zip_ref:
        print(f'Unzipping "{data_path}"')
        zip_ref.extractall(data_path)

    file_names = [
        "P3-data-documents.tsv",
        "P3-data-qrels.qrels",
        "P3-query-public.tsv",
        "P3-query-protected.tsv",
    ]
    contents = []
    for file_name in file_names:
        file_path = os.path.join(data_path, "data", file_name)
        with open(file_path, "r", encoding="utf-8-sig") as f:
            if file_name.endswith(".qrels"):
                qrels_dict = defaultdict(lambda: defaultdict(int))
                for line in f:
                    qid, _, doc_id, relevance = line.strip().split()
                    qrels_dict[str(qid)][str(doc_id)] = int(relevance)
                contents.append(defaultdict_to_dict(qrels_dict))
            elif file_name.endswith(".tsv"):
                tsv_dict = {}
                for line in f:
                    content_id, content_text = line.strip().split("\t")
                    tsv_dict[str(content_id)] = content_text
                contents.append(defaultdict_to_dict(tsv_dict))
            else:
                raise ValueError(f"Unrecognized File Type: {file_name}")
    return contents


class InvertedIndex:
    doc_ID_len_mapping: dict[str, int]  # mapping from doc_id to its length
    doc_cnt: int  # the number of documents in the collection
    doc_avg_len: float  # average document length
    total_term_cnt: int  # total amount of terms in the collection

    df_cache: dict[str, int]  # stores mapping from term to its document frequency
    cf_cache: dict[str, int]  # stores mapping from term to its collection frequency
    postings_lists: dict[
        str, dict[str, int]
    ]  # records the term frequency statistics for each term and document

    def __init__(self) -> None:
        self.doc_ID_len_mapping = defaultdict(int)
        self.doc_cnt = 0
        self.doc_avg_len = 0
        self.total_term_cnt = 0

        self.df_cache = Counter()
        self.cf_cache = Counter()
        self.postings_lists = defaultdict(lambda: defaultdict(int))

    def add(self, doc_id: str, doc_content: str) -> None:
        add_one_document_to_index(
            inverted_index=self, doc_id=doc_id, doc_terms=doc_content.strip().split()
        )

    def finalize(self) -> None:
        self.doc_avg_len = self.total_term_cnt / self.doc_cnt

    def __getitem__(self, term: str):
        return self.postings_lists.get(term)

    def __contains__(self, term: str) -> bool:
        return term in self.postings_lists

    def doc_len(self, doc_id: str) -> int:
        return self.doc_ID_len_mapping.get(doc_id, -1)

    @property
    def docs(self) -> list[str]:
        return list(self.doc_ID_len_mapping.keys())


def add_one_document_to_index(
    inverted_index: "InvertedIndex", doc_id: str, doc_terms: list[str]
) -> None:
    """
    Updates the inverted index with term frequency from the provided document.

    Args:
        inverted_index: The current inverted index.
        doc_id: The id for the document.
        doc_terms: The list of preprocessed terms in the document doc_id

    Returns:
        No Return as object updates do not require a variable reassignment
    """

    #########
    ##
    ## Implement the function here
    ##
    #########

    # updates collection statistics
    inverted_index.doc_ID_len_mapping[doc_id] = len(doc_terms)
    inverted_index.doc_cnt += 1
    inverted_index.total_term_cnt += len(doc_terms)

    # update term statistics
    inverted_index.df_cache.update(set(doc_terms))
    inverted_index.cf_cache.update(doc_terms)
    for term_idx, term in enumerate(doc_terms):
        inverted_index.postings_lists[term][doc_id] += 1


def build_inverted_index(documents: dict[str, str]) -> InvertedIndex:
    """
    Constructs an inverted index from a collection of documents.

    Args:
        documents: A list of document dictionaries.

    Returns:
        An inverted index (dict) containing terms as keys, with each term mapping to another dictionary.
        The inner dictionary maps document IDs to a list of term positions.
    """

    #########
    ##
    ## Implement the function here
    ##
    #########

    inverted_index = InvertedIndex()
    for doc_id, doc_content in documents.items():
        inverted_index.add(doc_id=doc_id, doc_content=doc_content)
    inverted_index.finalize()
    return inverted_index

    return {
        "sample_term": {"sample_doc": []}
    }  # You will return something meaningful before this statement


def tf(inverted_index: InvertedIndex, term: str, doc_id: str) -> int:
    """
    Get the term frequency (TF) for a given term in a specific document.

    Args:
        inverted_index (InvertedIndex): The inverted index data structure.
        term (str): The term for which we want to get the frequency.
        doc_id (str): The document id in which to count the term's occurrences.

    Returns:
        int: The frequnecy of the term in the document doc_id.
    """

    #########
    ##
    ## Implement the function here
    ##
    #########
    return (
        inverted_index[term][doc_id]
        if term in inverted_index and doc_id in inverted_index[term]
        else 0
    )
    return 0


def df(inverted_index: InvertedIndex, term: str) -> int:
    """
    Calculate the document frequency (DF) for a given term in a collection C.

    Args:
        inverted_index (InvertedIndex): The inverted index data structure
        term (str): The term

    Returns:
        int: The number of documents in the collection $C$ that contains the term.
    """

    #########
    ##
    ## Implement the function here
    ##
    #########

    return inverted_index.df_cache[term] if term in inverted_index else 0
    return 0


def cf(inverted_index: InvertedIndex, term: str) -> int:
    """
    Calculate the collection frequency (CF) of a given term in a collection C.

    Args:
        inverted_index (InvertedIndex): The inverted index
        term (str): The term t

    Returns:
        int: The number of times term t appears in the collection $C$
    """

    #########
    ##
    ## Implement the function here
    ##
    #########

    return inverted_index.cf_cache[term] if term in inverted_index else 0
    return 0


def tfm(
    inverted_index: InvertedIndex,
    queries: dict[str, str],
    top_k: int,
) -> dict[str, list[tuple[str, float]]]:
    """
    Compute TF scores for a collection of queries using the provided inverted index.

    Args:
        inverted_index (InvertedIndex): Inverted index with term postings and document lengths.
        queries (dict[str, str]): Mapping from query IDs to query strings.
        top_k (int): Number of top-ranked documents to return per query.

    Returns:
        dict[str, list[tuple[str, float]]]: Mapping from query IDs to lists of (doc_id, score) tuples,
                                             sorted by descending TF score.
    """
    tokenized_queries = {qid: q.strip().split() for qid, q in queries.items()}

    scores = {str(qid): defaultdict(float) for qid in tokenized_queries.keys()}
    for qid, terms in tokenized_queries.items():
        for term in terms:
            if term not in inverted_index:
                continue
            for doc_id in inverted_index[term].keys():
                scores[qid][doc_id] += tf(
                    inverted_index=inverted_index, term=term, doc_id=doc_id
                )

    return {
        str(qid): sorted(doc_scores.items(), key=lambda x: (-x[1], x[0]))[:top_k]
        for qid, doc_scores in scores.items()
    }


from math import log


def bm25(
    inverted_index: InvertedIndex,
    queries: dict[str, str],
    b: float,
    k1: float,
    top_k: int,
) -> dict[str, list[tuple[str, float]]]:
    """
    Compute BM25 scores for a collection of queries using the provided inverted index.

    Args:
        inverted_index (InvertedIndex): Inverted index with term postings and document lengths.
        queries (dict[str, str]): Mapping from query IDs to query strings.
        b (float): BM25 document length normalization parameter.
        k1 (float): BM25 term frequency scaling parameter.
        top_k (int): Number of top-ranked documents to return per query.

    Returns:
        dict[str, list[tuple[str, float]]]: Mapping from query IDs to lists of (doc_id, score) tuples,
                                             sorted by descending BM25 score.
    """
    tokenized_queries = {qid: q.strip().split() for qid, q in queries.items()}

    # Pre-compute IDF for each term in each query.
    idf_cache = {
        qid: {
            term: log(
                (
                    inverted_index.doc_cnt
                    - df(inverted_index=inverted_index, term=term)
                    + 0.5
                )
                / (df(inverted_index=inverted_index, term=term) + 0.5)
            )
            for term in terms
            if term in inverted_index
        }
        for qid, terms in tokenized_queries.items()
    }

    avgdl = inverted_index.doc_avg_len
    scores = {str(qid): defaultdict(float) for qid in tokenized_queries.keys()}

    for qid, terms in tokenized_queries.items():
        for term in terms:
            if term not in inverted_index:
                continue
            idf_val = idf_cache[qid][term]
            for doc_id in inverted_index[term].keys():
                tf_val = tf(inverted_index=inverted_index, term=term, doc_id=doc_id)
                doc_len = inverted_index.doc_len(doc_id)
                denominator = k1 * ((1 - b) + b * (doc_len / avgdl)) + tf_val
                scores[qid][doc_id] += idf_val * ((k1 + 1) * tf_val) / denominator

    return {
        str(qid): sorted(doc_scores.items(), key=lambda x: (-x[1], x[0]))[:top_k]
        for qid, doc_scores in scores.items()
    }


def ql(
    inverted_index: InvertedIndex,
    queries: dict[str, str],
    lambda_factor: float,
    top_k: int,
) -> dict[str, list[tuple[str, float]]]:
    """
    Compute Query Likelihood (QL) scores for queries using the inverted index.

    Args:
        inverted_index (InvertedIndex): Inverted index
        queries (dict[str, str]): Mapping from query IDs to query strings.
        lambda_factor (float): Smoothing parameter.
        top_k (int): Number of top-ranked documents to return per query.

    Returns:
        dict[str, list[tuple[str, float]]]: Mapping from query IDs to lists of (doc_id, score) tuples,
                                             sorted in descending order of retrieval score.
    """
    N = inverted_index.total_term_cnt
    tokenized_queries = {qid: q.strip().split() for qid, q in queries.items()}

    # Pre-compute collection frequency for each term in each query.
    cf_cache = {
        qid: {
            term: (cf(inverted_index=inverted_index, term=term) / N if N > 0 else 0)
            for term in terms
            if term in inverted_index
        }
        for qid, terms in tokenized_queries.items()
    }

    scores = {str(qid): defaultdict(float) for qid in tokenized_queries.keys()}
    for qid, terms in tokenized_queries.items():
        docs_with_at_least_one_term = set()
        for term in terms:
            if term not in inverted_index:
                continue
            docs_with_at_least_one_term.update(inverted_index[term])

        for doc_id in docs_with_at_least_one_term:
            for term in terms:
                if term not in inverted_index:
                    continue
                p_w_d = tf(
                    inverted_index=inverted_index, term=term, doc_id=doc_id
                ) / inverted_index.doc_len(doc_id)
                p_w_C = cf_cache[qid][term]
                score = log((1 - lambda_factor) * p_w_d + lambda_factor * p_w_C)
                scores[qid][doc_id] += score

    return {
        str(qid): sorted(doc_scores.items(), key=lambda x: (-x[1], x[0]))[:top_k]
        for qid, doc_scores in scores.items()
    }
